package com.service;
import java.io.*;

public class CSV_FileWriter {

	
	public void fileWriter(String csvLine, int flag) throws IOException
	{
     String fileName = "out.csv";
     File newFile = new File(fileName);
    PrintWriter writer = new PrintWriter(newFile);
     //FileWriter writer = new FileWriter(fileName);
		
    // writer.append(csvLine);
     writer.write(csvLine);
     
 	if(flag==1)
 	{
 	  writer.close();
 	}	

	 writer.close();
	
	
	}

	

}
