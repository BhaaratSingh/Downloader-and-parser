package com.service;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import com.mainPackage.*;



public class TxtFileReader {

	
	public ArrayList<String> reader(String fileName, String country, String weatherParam) throws IOException {

		String line = null;
		ArrayList<String> data = new ArrayList<String>();
		FileReader readsFile = new FileReader("Downloaded_Data\\" + fileName);
      //  Weather_Format wF = new Weather_Format();
		BufferedReader buffRead = new BufferedReader(readsFile);
        int flag =0;
        
        
		while ((line=buffRead.readLine()) != null) {
			
		  // System.out.println(line);
			if(line == null)
			{
			//	System.out.println("line is null :"+ line);
				continue;
			}
			
			if(line.startsWith("Year") && line.contains(" SEP "))
			{
				flag =1;
			//	System.out.println("Found year: "+line);
				continue;
			}
				
			
			
			
			// triming all leading and tailing white spaces
			
			if(flag==1&& line != null)
			{
				line.trim();
				data.addAll(objGen_Service(line,country,weatherParam));		
			}
			
      // adding objects to the array list
		}
		
	////////////////////////////////////////////////////////////////////////////////////////
		buffRead.close();
		return data;
		
	}

	public ArrayList<String> objGen_Service(String line,String country, String weatherParam) {
	String []key ={"JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC","WIN","SPR","SUM","AUT","ANN"};
     //  System.out.println(line);
		ArrayList<String> wFAlist = new ArrayList<String>();
       
		Weather_Format wF;
        line =line.trim();
        line = line+" ";
        StringBuilder sb = new StringBuilder(line);
		
		int k= sb.indexOf(" ");
		
		
		while(k!=sb.lastIndexOf(" "))
		{
           if(sb.charAt(k+1)==' ')
           {
        	   sb=sb.deleteCharAt(k+1);
           }
           else
           {
        	   
        	   sb=sb.replace(k,k+1,"#");
        	   k= sb.indexOf(" ");
        	 

        	   // k= sb.indexOf(",");
           }
			
		}
	//	System.out.println("line modified"+line+"\n"+k);
         sb.deleteCharAt(k);
		
		
	line = sb.toString();
       line= line.replaceAll("#", ",");
        String str[] = {};
         str = line.split(",");

     	
     //	System.out.println("i am here 1 "+line);
         //
     	
     	if(str.length==18 && (str[0].charAt(0)=='1'||str[0].charAt(0)=='2'))
     	{
     	//  System.out.println("i am here 2 "+line );
    	for(int i=0;i<17;i++)
         {
         	 wF = new Weather_Format();
        	 
           wF.setKey(key[i]);        	
           wF.setRegion_Code(country);
           wF.setWeather_param(weatherParam);
           wF.setYear((str[0]));
           wF.setValue((str[i+1]));
         
          //      System.out.println(wF.csvGen());   
           wFAlist.add(wF.csvGen());
        	 
         } 
        	 
         }
     	
    	return wFAlist;
	}
	
	
	

}
