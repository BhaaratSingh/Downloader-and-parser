package com.mainPackage;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.plaf.basic.BasicComboBoxUI.ComboBoxLayoutManager;

import com.service.*;

public class ParserMainClass {

    
	
	public static ArrayList<String> file = new ArrayList<String>();
	
    static String country[] = {"UK","England","Wales","Scotland"};
	static String weatherParam []={"Tmax","Tmin","Tmean","Sunshine","Rainfall","Raindays1mm"}; 
	
	
	
	
	public static void main (String args[]) throws IOException
	{
	  
		
		String  saveDir="Downloaded_Data";
		String 	fileURL = "";
		String fileName ="";
        SlowDownloader slowDown = new SlowDownloader();
      
     
      
      // sending the links to the downloader to download the .txt files
    /* for(int i=0;i<country.length;i++)
      {
    	  for(int j=0;j<weatherParam.length;j++)
          {
        	  fileURL = urlGenertor(country[i], weatherParam[j]);
        	  
        	   fileName = weatherParam[j];
        	  slowDown.downloader(fileURL, saveDir,fileName);
        	  
          }
     }*/
		
     

		
		
      parser();
	}
	
		

	// this function generates the URL of the text file
	public static String urlGenertor(String region, String weather_Param)
	{
	   String baseURL="https://www.metoffice.gov.uk/pub/data/weather/uk/climate/datasets/";	
		
	   baseURL += weather_Param+"/date/"+region+".txt";
	   
	   return baseURL;
	}
	
	public static void parser() throws IOException
	{
		CSV_FileWriter csvWriter = new CSV_FileWriter();
		TxtFileReader txtFileReader = new TxtFileReader();
		ArrayList<String> dataObjects= new ArrayList<String>();
	    String fileName = "out.csv";
		 PrintWriter writer = new PrintWriter(new File(fileName));
		 String conumnNames ="Region_Code,Weather_Param,Year,Key,Value";
	     //FileWriter writer = new FileWriter(fileName);
			
	    // writer.append(csvLine);
	  
		Weather_Format wFormat = new Weather_Format();
		
		/*
		Iterator<String> nameIterator = ParserMainClass.file.iterator();
            while(nameIterator.hasNext())
	     {
	    	 fileName= nameIterator.next();
	    	
	    	 txtFileReader.reader(fileName);
	    	 // Reading the text file present inside the Download_Data folder in this project
	     }
	     
	     */
	     
   	        for(String count: country)
   	        {
   	        	for(String wsString: weatherParam)
   	   	        {
   	   	        	fileName = count+"_"+wsString+'.'+"txt";
   	   	        	
   	        	    dataObjects.addAll(txtFileReader.reader(fileName,count,wsString));
   	   	        	
   	   	        	
   	   	        }	
   	        	
   	        }
   	        
   	        writer.write(conumnNames+'\n');;
     
   	        for(String csv : dataObjects)
   	        {
   	        	csv= csv+'\n';
   	       // 	csvWriter.fileWriter(csv,0);
   	             writer.write(csv);
   	        	System.out.println("ParserMainClass: "+csv);
   	        	
   	        }
   	      //  csvWriter.fileWriter("", 1);
	        writer.flush();
   	        writer.close();
   	   	System.out.println(dataObjects.size());
	     
	     
	}
	
	
}
