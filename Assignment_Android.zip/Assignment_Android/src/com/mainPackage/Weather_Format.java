package com.mainPackage;

public class Weather_Format {
	
	private String region_Code="";
	private String weather_param="";
	private String Year="";
	private String key="";
	private String value="";
	
	
	
	public String getRegion_Code() {
	
	
		
		return region_Code;
	}
	public void setRegion_Code(String region_Code) {
		this.region_Code = region_Code;
	}
	public String getWeather_param() {
		return weather_param;
	}
	public void setWeather_param(String weather_param) {
		this.weather_param = weather_param;
	}
	public String getYear() {
		return Year;
	}
	public void setYear(String year) {
		Year = year;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		if(value.contains("---"))
		{
			value= null;
		}
		
		this.value = value;
	}

	
	public String csvGen()
	{
		String csvLine ="";
		
		csvLine = this.region_Code+", "+this.weather_param+", "+this.Year+", "+this.key+", "+this.value;
		
	  return csvLine;
	}
	
	
}
